/*
 * Art.cpp
 *
 *  Created on: Sep. 2, 2023
 *      Author: moun
 */

#include "Art.h"

Art::Art() {
	// TODO Auto-generated constructor stub

}

Art::~Art() {
	// TODO Auto-generated destructor stub
}

int Art::getArr( int idx ) {
	return arr[ idx ];
}




