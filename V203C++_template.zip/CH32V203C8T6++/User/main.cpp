/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.cpp
 * Author             : CanHobby  ( git@canhobby.ca )
 * Version            : V1.0.0
 * Date               : 2023/09/05
 * Description        : Main C++ program body.
 * Derived from Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/

/****
 *@Note
 USART Print debugging routine:
 USART1_Tx(PA9).
 This example demonstrates using USART1(PA9) as a print debug port output.
*****/

#include "debug.h"
#include "Art.h"

/* Global typedef */

/* Global define */

/* Global Variable */
Art A_CLass;

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program.
 *
 * @return  none
 */
int main(void)
{
	int ClsArr;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("\n\nThis is a C++ example\r\n");

    ClsArr =  A_CLass.getArr( );  // defaults to element 2
    printf( "ClsArr = %d\r\n", ClsArr );

    ClsArr =  A_CLass.getArr( 0 );  //get element 0
    printf( "ClsArr = %d\r\n", ClsArr );

    while(1)
    {
    }
}
