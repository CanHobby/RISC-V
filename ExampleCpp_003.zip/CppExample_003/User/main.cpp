/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.cpp
 * Author             : CanHobby  ( git@canhobby.ca )
 * Version            : V1.0.0
 * Date               : 2023/09/05
 * Description        : Main C++ program body.
 * Derived from Nanjing Qinheng Microelectronics Co., Ltd.
 * SPDX-License-Identifier: Apache-2.0
 *******************************************************************************/

/****
 *@Note
 USART Printf debugging routine:
 USART1_Tx(PA9).
 This example demonstrates using USART1(PA9) as a printf debug port output.
 and includes a simple class (Art) as an example C++ class.
*****/

#include <CanHobby.h>   //  defines the class
#include "debug.h"

/* Global typedef */

/* Global define */

/* Global Variable */
CanHobby A_CLass;	//  instantiate the class

/*********************************************************************
 * @fn      main
 */

int main(void)
{
	int ClsArr;

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("\nSysClk = %d MHz\n\r", SystemCoreClock / 1000000 );
    printf("Chip is CH32V%03X id = %08X\r\n", DBGMCU_GetCHIPID() >> 20, DBGMCU_GetCHIPID() );

    printf("This is a C++ example\n\n\r");

    ClsArr =  A_CLass.getArr( );  // defaults to element 2
    printf( "ClsArr[default] = %d\n\r", ClsArr );

    ClsArr =  A_CLass.getArr( 0 );  // get element 0
    printf( "ClsArr[0] = %d\n\r", ClsArr );

    while(1)
    {
    	//  spin your wheels doing nothing
    }
}
